# C++ Pixels Library For Windows

This is the C++ Pixels library for Windows.
Windows Runtime [WinRT](https://github.com/microsoft/cppwinrt) APIs are used
to access Bluetooth.

Windows 10 version 1709 (Fall Creators Update) or more recent is required.

## Foreword

Pixels are full of LEDs, smarts and no larger than regular dice, they can be
customized to light up when and how you desire.
Check our [website](https://gamewithpixels.com/) for more information.

> **Warning**
> Before jumping into programming please make sure to read our Pixels developer's
> [guide](https://github.com/GameWithPixels/.github/blob/main/doc/DevelopersGuide.md).

Please open a [ticket](https://github.com/GameWithPixels/pixels-winrt-cpp/issues)
on GitHub if you're having any issue.

## Documentation

See the library documentation [here](https://gamewithpixels.github.io/PixelsWinRTCpp/modules.html).

Documentation generated with [Doxygen](https://www.doxygen.nl).

## License

MIT
