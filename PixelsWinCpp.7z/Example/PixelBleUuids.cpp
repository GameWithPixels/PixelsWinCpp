#include "pch.h"
#include "Systemic/Pixels/PixelBleUuids.h"

namespace Systemic::Pixels::PixelBleUuids
{
    const winrt::guid service("6e400001-b5a3-f393-e0a9-e50e24dcca9e");
    const winrt::guid notifyCharacteristic("6e400001-b5a3-f393-e0a9-e50e24dcca9e");
    const winrt::guid writeCharacteristic("6e400002-b5a3-f393-e0a9-e50e24dcca9e");
}
